﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using xNet;

namespace HexEyes
{
    internal class HexEYES
    {
        public string location { get; set; }
        public string nameimg { get; set; }
        public string decs { get; set; }
        public bool isTrue = false;

        private ChromeDriver creTask()
        {
            var driverService = ChromeDriverService.CreateDefaultService();
            driverService.HideCommandPromptWindow = true;

            ChromeOptions opt = new ChromeOptions();
            opt.AddArgument("headless");
            ChromeDriver driver = new ChromeDriver(driverService, opt);
            return driver;
        }

        public void proccess()
        {
            ChromeDriver driver = creTask();
            driver.Navigate().GoToUrl("https://www.imageidentify.com/");
            driver.FindElement(By.XPath("//*[@id=\"identify\"]/input")).SendKeys(location);
            for(int i = 0; i < 30; i++)
            {
                if (driver.PageSource.Contains("See full results from") || driver.PageSource.Contains("Try another image"))
                {
                    isTrue = true;
                    MessageBox.Show("[Rate craw: good] Cảm ơn đã sử dụng dịch vụ HexEye", "Trần Trọng Hòa có đôi lời:)");
                    break;
                }
                else
                {
                    Thread.Sleep(2000);
                }
            }
                
            if (isTrue)
            {
                try
                {
                    IJavaScriptExecutor js = driver as IJavaScriptExecutor;
                    string data = (string)js.ExecuteScript("var html = document.querySelector(\"#identify > form > h2\").innerHTML; return html;");
                    nameimg = StripHtmlTags(data).Trim();
                    File.WriteAllText("rs.kq", nameimg);
                } catch
                {
                    nameimg = "none";
                    File.WriteAllText("rs.kq", nameimg);
                }
                
                try
                {
                    IJavaScriptExecutor js = driver as IJavaScriptExecutor;
                    string data = (string)js.ExecuteScript("var html = document.querySelector(\"#identify-summaryboxes\").innerHTML; return html;");
                    decs = StripHtmlTags(data).Trim().Split("More information:")[0].Replace(":", ",").Replace("See full results from", "").Replace("»", "");
                    File.WriteAllText("rs.ds", decs);
                    
                } catch
                {
                    decs = "none";
                    File.WriteAllText("rs.ds", decs);
                }
                isTrue = false;
                driver.Quit();
            }
        }

     
        public string StripHtmlTags(string input)
        {
            string pattern = "<.*?>";
            return Regex.Replace(input, pattern, string.Empty);
        }
    }
}
