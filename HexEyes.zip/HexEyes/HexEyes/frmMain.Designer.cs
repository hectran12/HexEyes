﻿namespace HexEyes
{
    partial class frmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btn_sec_img = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_infoimage = new System.Windows.Forms.Label();
            this.lbl_path = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LBL_prOnlineView = new System.Windows.Forms.Label();
            this.btnproccess = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl_decs = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_is = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btn_sec_img);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Controls.Add(this.lbl_path);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox1);
            this.splitContainer1.Panel1.Controls.Add(this.LBL_prOnlineView);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnproccess);
            this.splitContainer1.Panel2.Controls.Add(this.button2);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.panel3);
            this.splitContainer1.Panel2.Controls.Add(this.panel2);
            this.splitContainer1.Size = new System.Drawing.Size(440, 450);
            this.splitContainer1.SplitterDistance = 221;
            this.splitContainer1.TabIndex = 0;
            // 
            // btn_sec_img
            // 
            this.btn_sec_img.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_sec_img.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sec_img.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_sec_img.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_sec_img.Location = new System.Drawing.Point(12, 176);
            this.btn_sec_img.Name = "btn_sec_img";
            this.btn_sec_img.Size = new System.Drawing.Size(200, 30);
            this.btn_sec_img.TabIndex = 5;
            this.btn_sec_img.Text = "Select Image";
            this.btn_sec_img.UseVisualStyleBackColor = false;
            this.btn_sec_img.Click += new System.EventHandler(this.btn_sec_img_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.lbl_infoimage);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 158);
            this.panel1.TabIndex = 4;
            // 
            // lbl_infoimage
            // 
            this.lbl_infoimage.AutoSize = true;
            this.lbl_infoimage.ForeColor = System.Drawing.Color.Green;
            this.lbl_infoimage.Location = new System.Drawing.Point(12, 10);
            this.lbl_infoimage.Name = "lbl_infoimage";
            this.lbl_infoimage.Size = new System.Drawing.Size(53, 15);
            this.lbl_infoimage.TabIndex = 0;
            this.lbl_infoimage.Text = "thongtin";
            // 
            // lbl_path
            // 
            this.lbl_path.AutoSize = true;
            this.lbl_path.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_path.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbl_path.Location = new System.Drawing.Point(52, 218);
            this.lbl_path.Name = "lbl_path";
            this.lbl_path.Size = new System.Drawing.Size(44, 15);
            this.lbl_path.TabIndex = 3;
            this.lbl_path.Text = "path://";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(12, 218);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Path:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 236);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 162);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // LBL_prOnlineView
            // 
            this.LBL_prOnlineView.AutoSize = true;
            this.LBL_prOnlineView.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LBL_prOnlineView.ForeColor = System.Drawing.SystemColors.Highlight;
            this.LBL_prOnlineView.Location = new System.Drawing.Point(12, 401);
            this.LBL_prOnlineView.Name = "LBL_prOnlineView";
            this.LBL_prOnlineView.Size = new System.Drawing.Size(114, 15);
            this.LBL_prOnlineView.TabIndex = 1;
            this.LBL_prOnlineView.Text = "Direct view images";
            // 
            // btnproccess
            // 
            this.btnproccess.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnproccess.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnproccess.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnproccess.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnproccess.Location = new System.Drawing.Point(12, 313);
            this.btnproccess.Name = "btnproccess";
            this.btnproccess.Size = new System.Drawing.Size(191, 30);
            this.btnproccess.TabIndex = 7;
            this.btnproccess.Text = "Image processing";
            this.btnproccess.UseVisualStyleBackColor = false;
            this.btnproccess.Click += new System.EventHandler(this.btnproccess_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Highlight;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Location = new System.Drawing.Point(12, 408);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(191, 30);
            this.button2.TabIndex = 6;
            this.button2.Text = "Đường đi tới phây bút:)";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(12, 383);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "Author: Tran Trong Hoa";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbl_decs);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(12, 89);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(191, 218);
            this.panel3.TabIndex = 1;
            // 
            // lbl_decs
            // 
            this.lbl_decs.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_decs.ForeColor = System.Drawing.Color.Red;
            this.lbl_decs.Location = new System.Drawing.Point(13, 37);
            this.lbl_decs.Name = "lbl_decs";
            this.lbl_decs.Size = new System.Drawing.Size(159, 168);
            this.lbl_decs.TabIndex = 1;
            this.lbl_decs.Text = "IMG_DEC";
            this.lbl_decs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Green;
            this.label4.Location = new System.Drawing.Point(13, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "More information";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl_is);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(191, 71);
            this.panel2.TabIndex = 0;
            // 
            // lbl_is
            // 
            this.lbl_is.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_is.ForeColor = System.Drawing.Color.Red;
            this.lbl_is.Location = new System.Drawing.Point(13, 37);
            this.lbl_is.Name = "lbl_is";
            this.lbl_is.Size = new System.Drawing.Size(159, 23);
            this.lbl_is.TabIndex = 1;
            this.lbl_is.Text = "IMG_IS";
            this.lbl_is.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(13, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "WHAT IS THAT PHOTO?";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(440, 450);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HexEyesAI";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private SplitContainer splitContainer1;
        private Label LBL_prOnlineView;
        private PictureBox pictureBox1;
        private Label lbl_path;
        private Label label1;
        private Button btn_sec_img;
        private Panel panel1;
        private Label lbl_infoimage;
        private Button button2;
        private Label label5;
        private Panel panel3;
        private Label lbl_decs;
        private Label label4;
        private Panel panel2;
        private Label lbl_is;
        private Label label2;
        private Button btnproccess;
    }
}