using GoogleTranslateFreeApi;
using Nancy.Json;
using System;
using System.Collections;
using System.Diagnostics;
using System.Drawing.Imaging;

namespace HexEyes
{
    public partial class frmMain : Form
    {
        static string filepath = "";
        public frmMain()
        {
            InitializeComponent();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.facebook.com/thehex101");
        }

        private void btn_sec_img_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            if(open.ShowDialog() == DialogResult.OK)
            {
                lbl_path.Text = open.FileName;
                Image img = Image.FromFile(open.FileName);
                pictureBox1.Image = img;
                ImageFormat format = img.RawFormat;
                FileInfo file = new FileInfo(open.FileName);
                lbl_infoimage.Text = "Image name : " + file.Name + "\n";
                lbl_infoimage.Text += "Image Type : " + format.ToString() + "\n";
                lbl_infoimage.Text += "Image width : " + img.Width + "\n";
                lbl_infoimage.Text += "Image height : " + img.Height + "\n";
                lbl_infoimage.Text += "Image Pixel depth : " + Image.GetPixelFormatSize(img.PixelFormat) + "\n";
                
                lbl_infoimage.Text += "Image create date : "+file.CreationTime.ToString("dd/MM/yyyy") + "\n";
                lbl_infoimage.Text += "Image create time : " + file.CreationTime.ToString("hh:mm:ss") + "\n";
                filepath = open.FileName;

                lbl_is.Text = "PROCCESS...";
              
                lbl_decs.Text = "PROCCESS...";
                btnproccess.Enabled = true;
            }
        }

        private void run (string path)
        {
            btn_sec_img.Enabled = false;
            HexEYES eye = new HexEYES();
            eye.location = path;
            Thread t = new Thread(() =>
            {
                eye.proccess();
                
            });
            t.Start();
            for (int i = 0; i < 30; i++)
            {
                if (eye.isTrue)
                {
                    Thread.Sleep(5000);
                    lbl_is.Text = File.ReadAllText("rs.kq");
                    lbl_decs.Text = File.ReadAllText("rs.ds");
                    break;
                }
                else
                {
                    Thread.Sleep(2000);
                }
            }
        }
        
        private void frmMain_Load(object sender, EventArgs e)
        {
            btnproccess.Enabled = false;
        }

        private void btnproccess_Click(object sender, EventArgs e)
        {
            run(filepath);
            btn_sec_img.Enabled = true;
        }
    }
}